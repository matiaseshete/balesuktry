from flet import *
import sqlite3
import base64
import shutil
import time


DB = 'white'
MB = '#97b4ff'
LB = 'yellow'
PINK = '#eb06ff'
TCW = 'black'






class RecentsView(UserControl):
    def __init__(self, ItemName, ItemUnit, ItemQty,  ItemuPrice,  ItemtPrice,DateTime ,ItemPic,Type):
        super().__init__()
        self.ItemName = ItemName
        self.ItemUnit = ItemUnit
        self.ItemQty = ItemQty


        self.ItemuPrice = ItemuPrice
        self.ItemtPrice = ItemtPrice
        self.DateTime = DateTime
        self.ItemPic = ItemPic
        self.Type = Type

    def build(self):

        self.Name_txt = Text(value=self.ItemName, size=20,color=TCW)
        self.Unit_txt = Text(value=self.ItemUnit,color=TCW)
        self.Qty_txt = Text(value=self.ItemQty ,
                            color=TCW, size=10)


        self.up_txt = Text(value='በ ' + str(self.ItemuPrice) + ' ብር',color=TCW,size=10,weight=FontWeight.BOLD)
        self.tp_txt = Text(value='ጠቅላላ '+str(self.ItemtPrice),color=TCW,size=10,weight=FontWeight.BOLD)
        self.date_txt = Text(value=self.DateTime,color=TCW,size=10,weight=FontWeight.BOLD)
        self.pic = Image(

            src=f'assets/uploads/{self.ItemPic}',
            fit=ImageFit.CONTAIN

        )
        self.Type_txt = Text(value=self.Type,size=20)

        self.type_cont = Container(
                            height=60,
                            width=0,
                            border_radius=20,
                            padding=padding.only(left=10,top=10),
                            animate=animation.Animation(1000, AnimationCurve.DECELERATE),
                            on_animation_end=self.shrink,
                            bgcolor=LB,
                            content=self.Type_txt
                        )


        self.pic_cont = Container(
                            on_click=self.restore,
                            height=60,
                            width=60,
                            border_radius=20,
                            animate=animation.Animation(1000, AnimationCurve.DECELERATE),
                            bgcolor=DB,
                            content=self.pic
                        )



        self.display_view = Container(
            animate=animation.Animation(600,AnimationCurve.DECELERATE),
            height=80,
            width=self.page.width,
            bgcolor=DB,
            padding=padding.only(left=10,right=10),
            shadow=BoxShadow(0, 40, 'black', Offset(3, 3), ShadowBlurStyle.INNER),
            border_radius=20,
            content=
                Row(
                    scroll=ScrollMode.AUTO,
                    controls=[
                        Row(controls=[self.type_cont,self.pic_cont]),
                        self.Name_txt,
                        self.Qty_txt,
                        self.Unit_txt,

                        Container(
                            height=35,
                            width=80,
                            padding=padding.only(bottom=10),
                            content=Column(
                                alignment=MainAxisAlignment.START,
                                spacing=1,
                                controls=[

                                    self.up_txt,self.tp_txt,self.date_txt
                                ]
                            )

                        ),
                        Container(
                            height=25,
                            width=10,
                            content=Column(
                                spacing=1,
                                controls=[



                                ]
                            )

                        )



                    ]
                )


        )

        return self.display_view

    def restore(self, e):
        self.type_cont.width = 60
        self.pic_cont.width = 0
        self.update()

    def shrink(self, e):
        self.type_cont.width = 0
        self.pic_cont.width = 60
        self.update()



class InventorySale(UserControl):
    def __init__(self, ItemName, ItemUnit, ItemQty, ItemuCost, ItemuPrice, ItemtCost, ItemtPrice, ItemPic,ItemId):
        super().__init__()
        self.ItemName = ItemName
        self.ItemUnit = ItemUnit
        self.ItemQty = ItemQty
        self.ItemuCost = ItemuCost
        self.ItemtCost = ItemtCost
        self.ItemuPrice = ItemuPrice
        self.ItemtPrice = ItemtPrice
        self.ItemPic = ItemPic
        self.ItemId = ItemId


    def build(self):
        self.tot_f = TextField(label='ጠቅላላ', width=80,height=40,
                                border_radius=20,border_color=LB,
                                bgcolor=MB,color='black', text_size=10,
                                keyboard_type=KeyboardType.NUMBER,
                                suffix_text='ብር' )
        self.text_f = TextField(label='ብዛት', width=70,height=40,
                                border_radius=20,border_color=LB,
                                bgcolor=MB,color='black', text_size=10,
                                suffix_text=self.ItemUnit, keyboard_type=KeyboardType.NUMBER,
                                on_change=lambda e:self.int_check(e))
        self.text_f2 = TextField(label='ዋጋ', width=70, value=self.ItemuCost,height=40,
                                border_radius=20, border_color=LB,
                                bgcolor=MB, color='black', text_size=10,keyboard_type=KeyboardType.NUMBER,
                                suffix_text="ብር")
        self.tot_btn = FloatingActionButton(icon=icons.ADD,
                                             width=30,height=30,
                                             on_click=lambda e: self.multiply(e))
        self.x_btn = FloatingActionButton(icon=icons.CLOSE,
                                            width=30, height=30,
                                            on_click=lambda e: self.quit(e))
        self.sale_btn = FloatingActionButton(icon=icons.MONETIZATION_ON_ROUNDED,
                                             text='ሽጥ',
                                             width=60,height=30,visible=False,
                                             on_click=lambda e: self.Shrink(e))
        self.Name_txt = Text(value=self.ItemName, size=26,color=TCW)
        self.Unit_txt = Text(value=str(self.ItemUnit),color=TCW)
        self.Qty_txt = Text(value='የቀረ ብዛት ' +str(self.ItemQty) ,
                            color=TCW, size=14)
        self.uc_txt = Text(value='መግዣ ' + str(self.ItemuCost)+' ብር',color=TCW,size=10)
        self.tc_txt = Text(value='ጠቅላላ የመግዣ ዋጋ ' + str(self.ItemtCost),color=TCW,size=10)
        self.up_txt = Text(value='መሸጫ ' + str(self.ItemuPrice) + ' ብር',color=TCW,size=10)
        self.tp_txt = Text(value='ጠቅላላ የመሸጫ ዋጋ '+str(self.ItemtPrice),color=TCW,size=10)
        self.id_txt = Text(value=self.ItemId)

        self.pic = Image(src=f'assets/uploads/{self.ItemPic}')
        self.cont = Container(animate=animation.Animation(400, AnimationCurve.DECELERATE),
            on_click=lambda e: self.Restore(e),
            height=80,
            width=80,
            border_radius=20,
            bgcolor=DB,
            content=self.pic
        )

        self.errortxt = Container(
            visible=False,
            height=30,
            border_radius=20,
            width=70,
            bgcolor='red',
            padding=padding.only(left=16,top=8),
            content=(Text('በቂ የለም',size=10))
        )

        self.sale_view = Container(
                        padding=padding.only(top=5,bottom=5,left=5,right=5),
                        width=0,
                        height=40,
                        border_radius=20,
                        bgcolor=MB,
                        animate=animation.Animation(500, AnimationCurve.DECELERATE),
            content=Column(controls=[Row(controls=[
                self.text_f,self.text_f2,self.errortxt,self.tot_btn,
            ]),Row(controls=[self.tot_f,self.x_btn,self.sale_btn])])
                    )

        self.display_view = Container(
            animate=animation.Animation(600,AnimationCurve.DECELERATE),
            height=160,
            width=self.page.width,
            bgcolor=DB,
            shadow=BoxShadow(0, 40, 'black', Offset(3, 3), ShadowBlurStyle.INNER),
            padding=padding.only(left=10,top=20),
            border_radius=20,
            content=
                Row(
                    scroll=ScrollMode.AUTO,

                    controls=[
                        Column(controls=[Row(controls=[self.cont,self.sale_view,
                        Container(
                            height=80,
                            width=120,
                            content=Column(
                                spacing=1,
                                controls=[Row(controls=[self.Qty_txt,self.Unit_txt]),
                                    self.uc_txt,
                                    self.up_txt,
                                    self.tc_txt,
                                    self.tp_txt
                                ]
                            )

                        ) ]),Container(width=240,content=Row(alignment=MainAxisAlignment.SPACE_BETWEEN,
                                                   controls=[
                                                       self.Name_txt,


                            Container(
                            on_click=self.Restore,
                            height=40,
                            width=60,
                            padding=padding.only(left=20,top=10),
                            bgcolor=MB,
                            border_radius=20,
                            content=Text('ሽጥ',size=14)
                        )]))

                        ])
                    ]
                )
        )
        return self.display_view
    def quit(self,e):
        self.sale_view.width = 0
        self.sale_view.height = 40
        self.display_view.height = 160
        self.text_f.value = ''
        self.tot_f.value = ''
        self.cont.width = 80

        self.update()


    def multiply(self,e):
        if self.text_f.value == '':
            self.sale_btn.visible = False

        if float(self.text_f.value) > float(self.ItemQty):
            self.text_f2.visible = False
            self.errortxt.visible = True
            self.sale_btn.visible = False

        elif float(self.text_f.value) <= float(self.ItemQty):
            self.text_f2.visible = True
            self.errortxt.visible = False
            self.sale_btn.visible = True
            q = float(self.text_f.value)
            p = float(self.text_f2.value)
            t = str(q * p)
            self.tot_f.value = t
            self.sale_btn.visible = True

        self.update()






    def int_check(self,e):
        if self.text_f.value == '':
            self.sale_btn.visible = False


        self.update()



    def Restore(self, e):
        self.sale_view.width = 200
        self.sale_view.height = 100
        self.text_f2.value = self.ItemuPrice
        self.display_view.height =180
        self.cont.width = 0

        self.update()

    def Shrink(self, e):
        id = self.id_txt.value
        time_object = time.localtime()

        format_time = time.strftime('%H:%M %b %d %y', time_object)

        subd = str(float(self.ItemQty) - float(self.text_f.value))
        tcost = str(float(self.ItemuCost) * float(subd))
        tprice = str(float(self.ItemuPrice) * float(subd))



        conn2 = sqlite3.connect('Inventory_Book.db')
        c = conn2.cursor()
        c.execute("""UPDATE Inventory_List SET 
                       quantity = :quantity,
                       unit_cost = :unit_cost,
                       total_cost = :total_cost,
                       total_price = :total_price
                       WHERE oid = :oid""",
                  {
                      'quantity': subd,
                      'unit_cost': self.ItemuCost,
                      'total_cost': tcost,
                      'total_price': tprice,

                      'oid': id
                  })

        conn2.commit()
        conn2.close()

        conn = sqlite3.connect('Inventory_Book.db')
        c = conn.cursor()
        c.execute("INSERT INTO Sales VALUES (:i_name, :i_unit, :i_qty , :i_uprice, :i_tprice, :datetime, :image)",
        {
            'i_name': self.ItemName,
            'i_unit': self.ItemUnit,
            'i_qty': self.text_f.value,
            'i_uprice': self.text_f2.value,
            'i_tprice': self.tot_f.value,
            'datetime': format_time,
            'image' : self.ItemPic
        }
        )

        conn.commit()
        conn.close()


        recents_list.controls.append(
            RecentsView(self.ItemName,self.ItemUnit,
                        self.text_f.value,self.text_f2.value,self.tot_f.value,format_time,self.ItemPic,'ሽያጭ')
        )



        self.cont.width = 80
        self.sale_view.height = 80
        self.display_view.height = 160

        self.sale_view.width = 0
        self.text_f.value = ''
        recents_list.controls.reverse()


        self.update()


class InventoryItem(UserControl):
    def __init__(self, ItemName, ItemUnit, ItemQty, ItemuCost, ItemuPrice, ItemtCost, ItemtPrice, ItemPic,ItemId):
        super().__init__()
        self.ItemName = ItemName
        self.ItemUnit = ItemUnit
        self.ItemQty = ItemQty
        self.ItemuCost = ItemuCost
        self.ItemtCost = ItemtCost
        self.ItemuPrice = ItemuPrice
        self.ItemtPrice = ItemtPrice
        self.ItemPic = ItemPic
        self.ItemId = ItemId

    def build(self):
        self.text_f = TextField(label='ብዛት', width=70,
                                border_radius=20,border_color=LB,
                                bgcolor=MB,color='black', text_size=10,
                                suffix_text=self.ItemUnit ,
                                on_submit=lambda e:self.int_check(e))
        self.text_f2 = TextField(label='ዋጋ', width=70, value=self.ItemuCost,
                                border_radius=20, border_color=LB,
                                bgcolor=MB, color='black', text_size=10,
                                suffix_text="ብር")
        self.sale_btn = FloatingActionButton(icon=icons.ADD,width=30,
                                             animate_rotation=animation.Animation(1000,AnimationCurve.DECELERATE),
                                             rotate=-10,
                                             on_click=lambda e: self.Shrink(e))
        self.quit_btn = FloatingActionButton(icon=icons.CLOSE, width=30,
                                             on_click=lambda e: self.quit(e))
        self.text_f3 = TextField(label='መሸጫ', width=70, value=self.ItemuPrice,
                                 border_radius=20, border_color=LB,
                                 bgcolor=MB, color='black', text_size=10,
                                 suffix_text="ብር")
        self.text_f4 = TextField(label='ጠቅላላ መግዣ', width=70, value=self.ItemtCost,
                                 border_radius=20, border_color=LB,
                                 bgcolor=MB, color='black', text_size=10,
                                 suffix_text="ብር")
        self.text_f5 = TextField(label='ጠቅላላ ', width=70, value=self.ItemtPrice,
                                 border_radius=20, border_color=LB,
                                 bgcolor=MB, color='black', text_size=10,
                                 suffix_text="ብር")


        self.Name_txt = Text(value=self.ItemName, size=24,color=TCW)
        self.Unit_txt = Text(value=str(self.ItemUnit),color=TCW)
        self.Qty_txt = Text(value='የቀረ ብዛት ' +str(self.ItemQty) ,
                            color=TCW, size=14)
        self.uc_txt = Text(value='መግዣ ' + str(self.ItemuCost)+' ብር',color=TCW,size=10)
        self.tc_txt = Text(value='ጠቅላላ የመግዣ ዋጋ ' + str(self.ItemtCost),color=TCW,size=10)
        self.up_txt = Text(value='መሸጫ ' + str(self.ItemuPrice) + ' ብር',color=TCW,size=10)
        self.tp_txt = Text(value='ጠቅላላ የመሸጫ ዋጋ '+str(self.ItemtPrice),color=TCW,size=10)
        self.pic = Image(src=f'assets/uploads/{self.ItemPic}')
        self.Id_txt = Text(str(self.ItemId))
        self.cont =Container(animate=animation.Animation(300,AnimationCurve.DECELERATE),
                            on_click=lambda e:self.Restore(e),
                            height=90,
                            width=90,
                            border_radius=20,
                            bgcolor=DB,
                            content=self.pic
                        )
        self.errortxt = Container(
            visible=False,
            height=30,
            border_radius=20,
            width=70,
            bgcolor='red',
            padding=padding.only(left=16,top=8),
            content=(Text('በቂ የለም',size=10))
        )

        self.sale_view = Container(
                        padding=padding.only(top=5,bottom=5,left=5,right=5),
                        width=0,
                        height=120,
                        border_radius=20,
                        bgcolor=MB,
                        animate=animation.Animation(500, AnimationCurve.DECELERATE),
            content=Row(controls=[
                self.text_f,self.text_f2,self.sale_btn,self.quit_btn
            ])
                    )

        self.display_view = Container(
            height=200,
            width=self.page.width,
            bgcolor=DB,
            shadow=BoxShadow(0, 40, 'black', Offset(3, 3), ShadowBlurStyle.INNER),
            padding=padding.only(left=10,top=10,right=10),
            border_radius=20,
            content=Column(alignment=MainAxisAlignment.START ,controls=[
                Row(

                    scroll=ScrollMode.AUTO,
                    controls=[
                        self.cont,self.sale_view,
                        Column(controls=[
                            Row(controls=[
                        self.Qty_txt,
                        self.Unit_txt]),

                        Container(
                            height=20,
                            width=150,
                            content=Column(
                                spacing=0,
                                controls=[
                                    self.tc_txt,
                                    self.tp_txt

                                ]
                            )

                        ),
                        Container(
                            height=20,
                            width=150,
                            content=Column(
                                spacing=0,
                                controls=[
                                    self.uc_txt,
                                    self.up_txt,
                                ]
                            ),
                        )]),




                    ]
                )
            ,Row(alignment=MainAxisAlignment.SPACE_BETWEEN,
                 controls=[Container(width=100,content=self.Name_txt),
                           Row(controls=[

                        Container(
                            height=40,
                            width=40,
                            bgcolor=MB,
                            border_radius=20,
                            content=Icon(icons.EDIT),
                            on_click=self.Restore
                        ),Container(
                            height=40,
                            width=40,
                            bgcolor=MB,
                            border_radius=20,
                            content=Icon(icons.DELETE),
                            on_click=self.deleteItem
                        )])]),Container(width=240,height=5,bgcolor=TCW,border_radius=5,
                       padding=padding.only(right=240 - int(self.ItemQty)*2),
                       content=Container(width=240,
                                         height=5,bgcolor=PINK,border_radius=5
                                         ))])

        )
        return self.display_view
    def deleteItem(self, e):
        conn = sqlite3.connect('Inventory_Book.db')
        c = conn.cursor()

        c.execute("DELETE from Inventory_List WHERE oid = :oid ",{'oid' : self.ItemId})
        conn.commit()
        conn.close()
        self.controls.clear()
        self.update()


    def quit(self, e):
        self.cont.width = 90
        self.sale_btn.rotate=-10


        self.sale_view.width = 0
        self.text_f.value = ''

        self.update()


    def int_check(self,e):
        if int(self.text_f.value) == '':
            self.sale_btn.visible = False
        else:
            self.sale_btn.visible = True







    def Restore(self, e):
        self.sale_view.width = 240
        self.cont.width = 0
        self.sale_btn.rotate = 0
        self.text_f2.value = self.ItemuCost
        self.update()

    def Shrink(self, e):
        time_object = time.localtime()

        format_time = time.strftime('%H:%M %b %d %y', time_object)

        id = self.Id_txt.value
        add = str(float(self.text_f.value) + float(self.ItemQty))
        tcost = str(float(self.ItemuCost) * float(add))
        tprice = str(float(self.ItemuPrice) * float(add))
        tp = str(float(self.text_f.value) * float(self.ItemuCost))
        cost = str(float(self.text_f.value) * float(self.text_f2.value))



        conn2 = sqlite3.connect('Inventory_Book.db')
        c = conn2.cursor()
        c.execute("""UPDATE Inventory_List SET 
                       quantity = :quantity,
                       unit_cost = :unit_cost,
                       total_cost = :total_cost,
                       total_price = :total_price
                       WHERE oid = :oid""",
                  {
                      'quantity': add,
                      'unit_cost': self.text_f2.value,
                      'total_cost': tcost,
                      'total_price': tprice,

                      'oid': id
                  })
        c.execute("INSERT INTO Purchase VALUES (:i_name, :i_unit, :i_qty , :i_ucost, :i_tcost, :datetime, :image)",
                  {
                      'i_name': self.ItemName,
                      'i_unit': self.ItemUnit,
                      'i_qty': self.text_f.value,
                      'i_ucost': self.text_f2.value,
                      'i_tcost': cost,
                      'datetime': format_time,
                      'image': self.ItemPic
                  }
                  )



        conn2.commit()
        conn2.close()




        print(id)

        recents_list.controls.append(
            RecentsView(self.ItemName,self.ItemUnit,self.text_f.value,self.ItemuCost,cost,format_time,self.ItemPic,'ግዢ')
        )



        self.cont.width = 90
        self.sale_btn.rotate = -10

        self.sale_view.width = 0
        self.text_f.value = '0'
        recents_list.controls.reverse()

        self.update()


def main(page: Page):



    def enable_btn(e):
        confirm_btn.disabled = False
        page.update()


    name_txt_f = TextField(
        border_radius=20,
                        label='ስም',
                        height=40,
                        width=140,
                        color=TCW,
                        on_change=enable_btn
                            )
    unit_txt_f = TextField(border_radius=20,
                        label='መለኪያ',
                        height=40,
                        width=140,
                        color=TCW
                            )
    qty_txt_f = TextField(border_radius=20,
                        label='ብዛት',
                        height=40,
                        width=140,
                        color=TCW,
                          keyboard_type=KeyboardType.NUMBER,


                            )
    ucost_txt_f = TextField(border_radius=20,
                        label='የአንዱ መግዣ',
                        height=40,
                        width=140,
                        color=TCW,
                            keyboard_type=KeyboardType.NUMBER
                            )
    tcost_txt_f = TextField(border_radius=20,
                        label='ጠቅላላ መግዣ',
                        disabled=True,
                        height=40,
                        width=140,
                        color=TCW,
                            keyboard_type=KeyboardType.NUMBER
                            )
    uprice_txt_f = TextField(
        border_radius=20,
                        label='የአንዱ መሸጫ',
                        height=40,
                        width=140,
                        color=TCW,
        keyboard_type=KeyboardType.NUMBER
                            )
    tprice_txt_f = TextField(
                        border_radius=20,
                        disabled=True,
                        label='ጠቅላላ መሸጫ',
                        height=40,
                        width=140,
                        color=TCW,
                        keyboard_type=KeyboardType.NUMBER
                            )



    def inv_back(e):
        Invent_list(e)
        page.go('/Inv_list')
        page.update()



    def Invent_list(e):
        page.go('/Inv_list')
        inv_viewer.controls.clear()
        inv_viewer.controls.reverse()


        conn2 = sqlite3.connect('Inventory_Book.db')
        c = conn2.cursor()
        c.execute("SELECT *, oid FROM Inventory_List")

        list_txt = c.fetchall()
        for l in list_txt:
            if str(l[4]) > '':
                inv_viewer.controls.append(
                    InventoryItem(l[0],l[1],l[2],l[3],l[4],l[5],l[6],l[7],l[8])
                )

        conn2.commit()
        conn2.close()
        inv_viewer.controls.append(
            ElevatedButton(text='አዲስ ጨምር', bgcolor=DB,on_click=addition_page)
        )
        inv_viewer.controls.reverse()

        page.update()

    def Sale_list(e):
        page.go('/Sales')
        Saleing_view.controls.clear()
        conn2 = sqlite3.connect('Inventory_Book.db')
        c = conn2.cursor()
        c.execute("SELECT *, oid FROM Inventory_List")

        list_txt = c.fetchall()
        for l in list_txt:
            if len(l[0]) >= 0:
                Saleing_view.controls.append(
                    InventorySale(l[0],l[1],l[2],l[3],l[4],l[5],l[6],l[7],l[8])
                )

        conn2.commit()
        conn2.close()
        Saleing_view.controls.reverse()

        page.update()

    global recents_list


    conn = sqlite3.connect('Inventory_Book.db')
    c = conn.cursor()
    c.execute("SELECT *, oid FROM Inventory_List")

    list_txt = c.fetchall()

    conn.commit()
    conn.close()

    print(list_txt)

    def saving_inventory(e):

        global invent_length
        time_object = time.localtime()

        format_time = time.strftime('%H:%M %b %d %y', time_object)

        recents_list.controls.append(
            RecentsView(name_txt_f.value,
                          unit_txt_f.value, qty_txt_f.value,
                          ucost_txt_f.value,
                          tcost_txt_f.value,format_time, img_name.value,'ግዢ')

        )

        conn = sqlite3.connect('Inventory_Book.db')
        c = conn.cursor()
        c.execute("INSERT INTO Inventory_List VALUES (:i_name, :i_unit, :i_qty"
                  ", :i_ucost, :i_uprice,:i_tcost, :i_tprice, :i_image)",
                  {
                      'i_name': name_txt_f.value,
                      'i_unit': unit_txt_f.value,
                      'i_qty': qty_txt_f.value,
                      'i_ucost': ucost_txt_f.value,
                      'i_uprice': uprice_txt_f.value,
                      'i_tcost': tcost_txt_f.value,
                      'i_tprice': tprice_txt_f.value,
                      'i_image' : img_name.value
                  }
                  )

        c.execute("INSERT INTO Purchase VALUES (:i_name, :i_unit, :i_qty"
                  ", :i_ucost, :i_tcost, :datetime, :i_image)",
                  {
                      'i_name': name_txt_f.value,
                      'i_unit': unit_txt_f.value,
                      'i_qty': qty_txt_f.value,
                      'i_ucost': ucost_txt_f.value,
                      'i_tcost': tcost_txt_f.value,
                      'datetime': format_time,
                      'i_image': img_name.value
                  }
                  )

        conn.commit()
        conn.close()

        recents_list.controls.reverse()
        Invent_list(e)

        page.update()

    invent_length = str(len(list_txt))
    img_name=Text('', visible=False)

    def Handler(e: FilePickerResultEvent):
        if file_picker.result != None and file_picker.result.files != None:
            for f in file_picker.result.files:
                shutil.copy(f.path,f'assets/uploads/{f.name}')
                img_name.value = f.name
                img_name.update()



        if e.files and len(e.files):
            with open(e.files[0].path, 'rb') as r:
                act_img.src_base64 = base64.b64encode(r.read()).decode('utf-8')
                act_img.visible = True
                img_btn.visible = False



                page.update()


    def Multiply(e):
        if name_txt_f.value and unit_txt_f.value and qty_txt_f.value and uprice_txt_f.value and \
        ucost_txt_f.value > '':
            tprice_txt_f.value = str(float(qty_txt_f.value) * float(uprice_txt_f.value) )
            tcost_txt_f.value = str(float(qty_txt_f.value) * float(ucost_txt_f.value))
            confirm_btn.visible = True
            page.update()

    confirm_btn = ElevatedButton(
                        visible=False,
                        elevation=10,
                        text='ወደ ማከማቻ ጨምር',
                        height=40,
                        width=290 ,
                        on_click=saving_inventory
                                )
    multiplyBtn = ElevatedButton(
                        elevation=10,
                        text='አረጋግጥ',
                        height=40,
                        width=290 ,
                        on_click=Multiply
                                )

    file_picker = FilePicker(on_result=Handler)
    page.overlay.append(file_picker)


    img_btn = FloatingActionButton(
                        on_click=lambda _: file_picker.pick_files(allow_multiple=False,
                                                                  allowed_extensions=['jpg', 'png', 'jpeg']),
                        height=130,
                        width=140,
                        icon=icons.ADD,
                        text='ምስል አስገባ',
                                )
    act_img = Image(visible=False, fit=ImageFit.CONTAIN)
    img_holder = Stack(controls=[Container(height=120,
                        width=120, content=act_img),img_name,img_btn])



    def shrink(e):
        page_2.controls[0].width = 120
        page_2.controls[0].scale = transform.Scale(0.5, alignment=alignment.center_right)
        page.update()

    def restore(e):

        page_2.controls[0].width = 300
        page_2.controls[0].scale = transform.Scale(1, alignment=alignment.center_right)
        page.update()





    adding_view = Container(
        expand=True,
        bgcolor=LB,
        border_radius=35,
        padding=padding.only(left=10, top=10, right=10),
        content=
        Column(
            controls=[Container(
                height=20
            ),
                Container(

                    width=page.width,
                    height=50,
                    bgcolor=DB,
                    border_radius=20,
                    shadow=BoxShadow(0, 40, 'black', Offset(3, 3), ShadowBlurStyle.INNER),
                    padding=padding.only(left=10, right=50),
                    content=Row(alignment=MainAxisAlignment.SPACE_BETWEEN,
                        controls=[
                            IconButton(icons.INVENTORY, bgcolor=TCW,
                                       on_click=inv_back),
                            Text('አዲስ ክምችት ', color=TCW, size=20),
                            Container()
                        ]
                    )
                ),Container(height=10)
            ,Container(
                    height=360,
                    width=page.width,
                    bgcolor=DB,
                    border_radius=10,
                    padding=padding.only(left=5,right=5,top=5, bottom=5),
                    shadow=BoxShadow(0, 40, 'black', Offset(3, 3), ShadowBlurStyle.INNER),
                    content=Container(
                        padding=padding.only(left=10, right=10,),
                        bgcolor=DB,
                        border_radius=10,
                        content=Column(expand=True,
                            controls=[Container(height=5),
                                Row(
                                    controls=[
                                        Column(
                                            controls=[
                                                name_txt_f,
                                                unit_txt_f,
                                                qty_txt_f,
                                            ]
                                        ),Container(
                                            content=img_holder
                                        )

                                    ]
                                ),
                                Row(
                                    controls=[ucost_txt_f,
                                            tcost_txt_f]
                                ),
                                Row(
                                    controls=[
                                        uprice_txt_f,
                                        tprice_txt_f,
                                    ]
                                ), confirm_btn,multiplyBtn

                            ]
                        )
                    )

                )

                    ]))
    page.overlay.append(file_picker)

    def addition_page(e):
        if uprice_txt_f.value == '':
            confirm_btn.disabled = True

        page.go('/Inventory')
        page.overlay.append(file_picker)
        act_img.visible=False
        img_btn.visible=True
        confirm_btn.visible = False
        img_name.value = ''
        name_txt_f.value = ''
        unit_txt_f.value = ''
        qty_txt_f.value = ''
        ucost_txt_f.value = ''
        tcost_txt_f.value = ''
        uprice_txt_f.value = ''
        tprice_txt_f.value = ''

        page.update()

    global Sales_viewer

    Sales_viewer = Column(
        scroll=ScrollMode.AUTO

    )

    Sales_List_veiw = Container(
        expand=True,
        bgcolor=DB,
        border_radius=35,
        padding=padding.only(left=10, top=10, right=10),
        content=
        Column(
            controls=[Container(
                height=20
            ),
                Container(
                    height=60,
                    width=page.width,
                    bgcolor=LB,
                    border_radius=20,
                    padding=padding.only(left=10, right=50),
                    content=Row(alignment=MainAxisAlignment.SPACE_BETWEEN,
                                controls=[
                                    IconButton(icons.HOME, bgcolor=TCW,
                                               on_click=lambda _: page.go('/')),
                                    Text('የሽያጭ ዝርዝር', color=TCW, size=20),

                                ]
                                )
                ), Container(border_radius=25,
                                             expand=True,
                                             width=page.width,


                                             bgcolor=LB,
                                             padding=padding.only(left=10, top=10,right=10,bottom=10),
                                             content=Sales_viewer

                                             )]))

    search_field = TextField(height=40,expand=True,border_color=DB)

    def slideUp(e):
        appBar.height=60
        page.update()

    def viewResults(e):

        conn = sqlite3.connect('Inventory_Book.db')
        c = conn.cursor()
        c.execute("SELECT *,oid from Inventory_List")

        r_list = c.fetchall()

        conn.commit()
        conn.close()
        list = []
        for r in r_list:
            if r[0] == search_field.value:
                inv_viewer.controls.clear()

                inv_viewer.controls.append(
                    InventoryItem(r[0],r[1],r[2],r[3],r[4],r[5],r[6],r[7],r[8])

                )
                list.append(r[0])



                appBar.height = 60
                search_field.value = ''

        if list == []:
                inv_viewer.controls.clear()

                inv_viewer.controls.append(Text(value='ክምችት ውስጥ ምንም ' + str(search_field.value) + ' የለም'))
                search_field.value = ''
                appBar.height = 60
        inv_viewer.controls.append( ElevatedButton(text='ተመለስ', on_click=Invent_list))
        page.update()


    searchBar = Container(height=0,
                          width=page.width,
                          border_radius=20,
                          bgcolor=DB,
                          animate=animation.Animation(600, AnimationCurve.DECELERATE),
                          content=Row(alignment=MainAxisAlignment.SPACE_BETWEEN,
                                      controls=[search_field,
                                                IconButton(icon=icons.SEARCH,on_click=viewResults)
                                          ,IconButton(icons.CLOSE,on_click=slideUp)])
                          )
    def slideDown(e):
        appBar.height = 110
        searchBar.height = 40
        page.update()


    appBar = Container(
                    height=60,
                    width=page.width,
                    bgcolor=LB,
                    border_radius=20,
                    padding=padding.only(left=10, right=10,top=10,bottom=10),
                    animate=animation.Animation(600, AnimationCurve.DECELERATE),
                    content=Column(controls=[Row(alignment=MainAxisAlignment.SPACE_BETWEEN,
                                controls=[
                                    IconButton(icons.HOME, bgcolor=TCW,
                                               on_click=lambda _: page.go('/')),
                                    Row(controls=[Text('ክምችት', color=TCW, size=20),IconButton(icons.SEARCH,on_click=slideDown)]),

                                ]
                                ),searchBar])
                )

    inv_viewer = Column(
        scroll=ScrollMode.AUTO

    )



    invent_view = Container(

        expand=True,
        bgcolor=DB,
        border_radius=35,
        padding=padding.only(left=10, top=10, right=10),
        content=
        Column(
            controls=[Container(
                height=20
            ),
                appBar, Container(
                                        border_radius=25,
                                        expand=True,

                                        width=page.width,

                                        bgcolor=LB,
                                        padding=padding.only(left=10,top=10,right=10,bottom=10),
                                        content=inv_viewer

                                    )]))

    Purchase_view = Column(
        scroll=ScrollMode.AUTO)

    Purch_view = Container(
        expand=True,
        bgcolor=DB,
        border_radius=35,
        padding=padding.only(left=10, top=10, right=10),
        content=
        Column(
            controls=[Container(
                height=20
            ),
                Container(
                    width=page.width,
                    height=60,
                    bgcolor=LB,
                    border_radius=20,
                    padding=padding.only(left=10, right=50),
                    content=Row(alignment=MainAxisAlignment.SPACE_BETWEEN,
                                controls=[
                                    IconButton(icons.HOME, bgcolor=TCW,
                                               on_click=lambda _: page.go('/')),
                                    Text('ግዢ', color=TCW, size=20),

                                ]
                                )
                ),Container(border_radius=25,
                             expand=True,
                             width=page.width,
                             padding=padding.only(left=10,top=10,right=10,bottom=10),
                             bgcolor=LB,
                             content=Purchase_view

                             )]))

    def viewResultssales(e):

        conn = sqlite3.connect('Inventory_Book.db')
        c = conn.cursor()
        c.execute("SELECT *,oid from Inventory_List")

        r_list = c.fetchall()

        conn.commit()
        conn.close()
        list = []
        for r in r_list:
            if r[0] == search_fieldsales.value:
                Saleing_view.controls.clear()

                Saleing_view.controls.append(
                    InventorySale(r[0],r[1],r[2],r[3],r[4],r[5],r[6],r[7],r[8])

                )
                list.append(r[0])



                appBarsales.height = 60
                search_fieldsales.value = ''

        if list == []:
                Saleing_view.controls.clear()

                Saleing_view.controls.append(Text(value='ክምችት ውስጥ ምንም ' + str(search_fieldsales.value) + ' የለም'))
                search_fieldsales.value = ''
                appBarsales.height = 60
        Saleing_view.controls.append( ElevatedButton(text='ተመለስ', on_click=Sale_list))
        page.update()

    search_fieldsales = TextField(height=40, expand=True, border_color=DB)


    def slideDownsales(e):
        appBarsales.height = 110
        searchBarsales.height = 40
        page.update()



    def slideUpsales(e):
        appBarsales.height=60
        page.update()




    searchBarsales = Container(height=0,
                          width=page.width,
                          border_radius=20,
                          bgcolor=DB,
                          animate=animation.Animation(600, AnimationCurve.DECELERATE),
                          content=Row(alignment=MainAxisAlignment.SPACE_BETWEEN,
                                      controls=[search_fieldsales,
                                                IconButton(icon=icons.SEARCH, on_click=viewResultssales)
                                          , IconButton(icons.CLOSE, on_click=slideUpsales)])
                          )


    Saleing_view = Column(
        scroll=ScrollMode.AUTO)

    appBarsales = Container(
        height=60,
        width=page.width,
        bgcolor=LB,
        border_radius=20,
        padding=padding.only(left=10, right=10, top=10, bottom=10),
        animate=animation.Animation(600, AnimationCurve.DECELERATE),
        content=Column(controls=[Row(alignment=MainAxisAlignment.SPACE_BETWEEN,
                                     controls=[
                                         IconButton(icons.HOME, bgcolor=TCW,
                                                    on_click=lambda _: page.go('/')),
                                         Row(controls=[Text('ሽያጭ', color=TCW, size=20),
                                                       IconButton(icons.SEARCH, on_click=slideDownsales)]),

                                     ]
                                     ), searchBarsales])
    )

    Sale_view = Container(
        expand=True,
        bgcolor=DB,
        border_radius=35,
        padding=padding.only(left=10, top=10, right=10),
        content=
        Column(
            controls=[Container(
                height=20
            ),
               appBarsales, Container(border_radius=25,
                             expand=True,
                             width=page.width,
                             padding=padding.only(left=10, top=10, right=10, bottom=10),
                             bgcolor=LB,
                             content=Saleing_view

                             )]))



    recents_list = Column(

        scroll=ScrollMode.AUTO,

    )



    conn2 = sqlite3.connect('Inventory_Book.db')
    c2 = conn2.cursor()
    c2.execute("SELECT *, oid FROM Sales")

    list_sales = c2.fetchall()

    conn2.commit()
    conn2.close()

    conn2 = sqlite3.connect('Inventory_Book.db')
    c2 = conn2.cursor()
    c2.execute("SELECT *, oid FROM Purchase")

    list_purch = c2.fetchall()
    purch_length = str(len(list_purch))

    conn2.commit()
    conn2.close()

    def Purch_list(e):
        page.go('/Purch_list')
        Purchase_view.controls.clear()

        conn2 = sqlite3.connect('Inventory_Book.db')
        c = conn2.cursor()
        c.execute("SELECT *, oid FROM Purchase")

        list = c.fetchall()

        x = 0.0

        for l in list:
            if str(l[4]) > '':
                Purchase_view.controls.append(
                    RecentsView(l[0], l[1], l[2], l[3], l[4], l[5],l[6],'ግዢ')


                )
                y = float(l[4])
                x += y

        total = str(x)
        Purchase_view.controls.append(
            Container(
                animate=animation.Animation(600, AnimationCurve.DECELERATE),
                height=60,
                width=270,
                bgcolor=DB,
                padding=padding.only(left=10),
                border_radius=20,
                content=Row(scroll=ScrollMode.AUTO, spacing=2,
                            controls=[
                                Container(
                                    width=40,
                                    height=40,
                                    bgcolor='white',

                                    border_radius=20,
                                    content=Icon(icons.MONETIZATION_ON_ROUNDED)
                                ),
                                Container(
                                    width=120,
                                    height=40,
                                    bgcolor=MB,
                                    padding=padding.only(top=10, left=7),
                                    border_radius=20,
                                    content=Text(value='ጠቅላላ የግዢ መጠን', )
                                ), Container(
                                    width=90,
                                    height=40,
                                    bgcolor=MB,
                                    padding=padding.only(top=10, left=7),
                                    border_radius=20,
                                    content=Text(value=total, size=12)

                                )
                            ])
            )
        )

        conn2.commit()
        conn2.close()

        Purchase_view.controls.reverse()



        page.update()



    def Sold_list(e):
        page.go('/Soldview')
        Sales_viewer.controls.clear()

        conn2 = sqlite3.connect('Inventory_Book.db')
        c = conn2.cursor()
        c.execute("SELECT *, oid FROM Sales")

        list = c.fetchall()

        x = 0.0

        for l in list:
            if str(l[4]) > '':
                Sales_viewer.controls.append(
                    RecentsView(l[0], l[1], l[2], l[3], l[4], l[5],l[6],'ሽያጭ')


                )
                y = float(l[4])
                x += y

        total = str(x)
        Sales_viewer.controls.append(
            Container(
                animate=animation.Animation(600, AnimationCurve.DECELERATE),
                height=60,
                width=270,
                bgcolor=DB,
                padding=padding.only(left=10),
                border_radius=20,
                content=Row(scroll=ScrollMode.AUTO, spacing=2,
                            controls=[
                                Container(
                                    width=40,
                                    height=40,
                                    bgcolor='white',

                                    border_radius=20,
                                    content=Icon(icons.MONETIZATION_ON_ROUNDED)
                                ),
                                Container(
                                    width=120,
                                    height=40,
                                    bgcolor=MB,
                                    padding=padding.only(top=10, left=7),
                                    border_radius=20,
                                    content=Text(value='ጠቅላላ የሽያጭ ገቢ', )
                                ), Container(
                                    width=90,
                                    height=40,
                                    bgcolor=MB,
                                    padding=padding.only(top=10, left=7),
                                    border_radius=20,
                                    content=Text(value=total, size=12)

                                )
                            ])
            )
        )

        conn2.commit()
        conn2.close()

        Sales_viewer.controls.reverse()



        page.update()




    status_card = Row(

        spacing=10,
        scroll=ScrollMode.AUTO,controls=[Container(height=110,width=0),
            Container(

                on_click=Sale_list,
                shadow=BoxShadow(0,40,'black',Offset(-3,3),ShadowBlurStyle.INNER),

                bgcolor=DB,
                width=170,
                height=110,
                border_radius=20,
                padding=10,
                content=Column(
                    controls=[
                        Text(value='የክምችት መጠን : ' + invent_length, color=TCW, size=10),
                        Text(value='ሽያጭ', color=TCW,size=30),
                        Container(
                            height=5,
                            width=150,
                            bgcolor=TCW,
                            border_radius=20,
                            padding=padding.only(right=150 - (2.5 * len(list_sales))),
                            content=Container(
                                bgcolor=PINK,
                            )
                        )
                    ]
                )
            )
            ,Container(
                on_click=Invent_list,
                bgcolor=DB,
                shadow=BoxShadow(0,40,'black',Offset(-3,3),ShadowBlurStyle.INNER),
                width=170,
                height=110,
                border_radius=20,
                padding=10,
                content=Column(
                    controls=[
                        Text(value='የክምችት መጠን : ' + invent_length, color=TCW, size=10),
                        Text(value='ክምችት', color=TCW,size=30),
                        Container(
                            height=5,
                            width=150,
                            bgcolor=TCW,
                            border_radius=20,
                            padding=padding.only(right=150 - (1.5 * len(list_txt))),
                            content=Container(
                                bgcolor=PINK,
                            )
                        )
                    ]
                )
            ),Container(
                on_click=Sold_list,
                bgcolor=DB,
                width=170,
                height=110,
                border_radius=20,
                shadow=BoxShadow(0, 40, 'black', Offset(-3, 3), ShadowBlurStyle.INNER),
                padding=10,
                content=Column(
                    controls=[
                        Text(value='የሽያጭ መጠን : ' + str(len(list_sales)), color=TCW, size=10),
                        Text(value='የሽያጭ ዝርዝር', color=TCW,size=20),
                        Container(
                            height=5,
                            width=150,
                            bgcolor=TCW,
                            border_radius=20,
                            padding=padding.only(right=150 - (1.5 * len(list_sales))),
                            content=Container(
                                bgcolor=PINK,
                            )
                        )
                    ]
                )
            ), Container(

                on_click=Purch_list,
                shadow=BoxShadow(0,40,'black',Offset(-3,3),ShadowBlurStyle.INNER),

                bgcolor=DB,
                width=170,
                height=110,
                border_radius=20,
                padding=10,
                content=Column(
                    controls=[
                        Text(value='የክምችት መጠን : ' + purch_length, color=TCW, size=10),
                        Text(value='የግዢ ዝርዝር', color=TCW,size=20),
                        Container(
                            height=5,
                            width=150,
                            bgcolor=TCW,
                            border_radius=20,
                            padding=padding.only(right=150 - (2.5 * len(list_purch))),
                            content=Container(
                                bgcolor=PINK,
                            )
                        )
                    ]
                )
            )
        ]
    )





    first_page_contents = Container(
        content=Column(
            controls=[
                Row(alignment=MainAxisAlignment.SPACE_BETWEEN,
                    controls=[
                        Container(on_click=lambda e: shrink(e),
                            content=Icon(
                                icons.MENU)),
                        Row(
                            controls=[

                                Icon(icons.NOTIFICATIONS_OUTLINED)
                            ])
                    ]
                ),
                Text(value='የክምችትና የሽያጭ ማስተዳደርያ ',color=TCW,size=20),
                Text(value='አሁንታዎች',color=TCW),
                Container(
                    height=150,
                    padding=padding.only(top=10, bottom=20),
                    content=status_card
                ),
                Text("የቅርብ ጊዜ", color=TCW),
                Container(
                    height=260,
                    width=page.width,
                    border_radius=20,
                    content=

                                Container(
                                    height=260,
                                    width=400,

                                    border_radius=20,
                                    content=(
                                        recents_list
                                    )

                                ),



                )



            ]
        )
    )

    page_1 = Container(
        width=300,
        height=650,
        bgcolor=DB,
        border_radius=35,
        padding=padding.only(left=40, top=60, right=100),
        content=Column(
                controls=[
                    Row(alignment=MainAxisAlignment.END,
                        controls=[
                            Container(
                                on_click=lambda e: restore(e),
                                height=50,
                                width=50,
                                border_radius=25,
                                border=border.all(width=3, color=TCW),
                                content=Text(value=' <', color=TCW)
                            )
                        ]
                    ),
                            Container(
                                height=100,
                                width=100,
                                border=border.all(width=4, color=PINK),
                                border_radius=50,
                                content=Image(
                                        src=f"/images/img1.png",
                                        width=300,
                                        height=300,
                                        border_radius=20,
                                        ),


                                ),

                    Text(value='    ባለ ሱቅ', size=20 , color=TCW),
                    Row(
                        controls=[
                            Icon(
                                icons.SETTINGS,color=TCW,
                            ),
                            Text(value='መቼት',color=TCW)
                        ]
                    ),
                    Row(
                        controls=[

                            Icon(icons.INFO_OUTLINE, color=TCW),
                            Text(value='ስለ እኛ', color=TCW)
                        ]
                    )
                ]
            )
        )

    page_2 = Row(alignment= MainAxisAlignment.END,
        controls=[
            Container(
                expand=True,
                bgcolor=LB,
                border_radius=35,
                animate=animation.Animation(600, AnimationCurve.DECELERATE),
                animate_scale=animation.Animation(400, AnimationCurve.DECELERATE),
                padding=padding.only(
                    top=50, left=20,
                    right=20, bottom=5
                ),
                content=Column(
                    controls=[
                        first_page_contents
                    ]

                )
            )
        ]
    )

    contain = Container(

        expand=True,
        bgcolor=DB,
        border_radius=35,
        content=Stack(
            controls=[
                page_1,
                page_2
            ]
        )
    )
    page.add(contain)



    def route_change(e: RouteChangeEvent):

        page.views.clear()

        page.views.append(
            View(
                route='/',
                controls=[
                    contain
                    ]
            )
        )

        if page.route == '/Inv_list':
            page.views.append(
                View(
                    route='/Inv_list',
                    controls=[
                        invent_view

                    ]

                )
            )

        if page.route == '/Purch_list':
            page.views.append(
                View(
                    route='/Purch_list',
                    controls=[
                        Purch_view

                    ]

                )
            )

        if page.route == '/Inventory':

            page.views.append(
                View(
                    route='/Inventory',
                    controls=[
                        adding_view
                    ]

                )
            )

        if page.route == '/Soldview':
            page.views.append(
                View(
                    route='/Soldview',
                    controls=[
                        Sales_List_veiw
                    ]

                )
            )

        if page.route == '/Sales':

            page.views.append(
                View(
                    route='/Sales',
                    controls=[
                        Sale_view
                    ]

                )
            )



        page.update()


    def view_pop(e: ViewPopEvent):
        page.views.pop()
        top_view: View = page.views[-1]
        page.go(top_view.route)

    page.on_route_change = route_change
    page.on_view_pop = view_pop
    page.go(page.route)




app(target=main, assets_dir='assets', upload_dir='assets/uploads')
